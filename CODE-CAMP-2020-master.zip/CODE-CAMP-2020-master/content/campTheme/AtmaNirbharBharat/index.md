---
title: AtmaNirbhar Bharat
date: "2020-06-30"
description: "Replacing 59 Banned Apps Or Idea Innovation"
type: "theme"
priority: "1"
---

![](https://inc42.com/wp-content/uploads/2020/05/atmanirbhar.jpg)

# **Overview**

Aatma Nirbhar Bharat: On 12th May, our Prime Minister launched Aatma Nirbhar Bharat Abhiyan and as the words speak, it is a mission to make India self-reliant and self-sustainable. Later, Aatma Nirbhar Bharat package was also announced by the government. On 13th July, Google announced to invest $10B in India to support digitalisation in the country. In the past two decades, our dependence on China has grown and huge trade imbalance is not good for any country. Also Chinese applications are a threat to India's security and because of these reasons, the Government banned 59 Chinese apps. This has created a large room for 'Made in India' apps and new innovations. Days after the ban, PM launched 'Aatmanirbhar Bharat App Innovation Challenge' and urged start-ups and tech community to participate in it. There is a wide range of categories in which technology can help India achieve its goal. These include gaming, business, entertainment, social networking, supply chain management, etc. Apart from this, there is no limit to innovation and creativity. Can you help India become Aatma Nirbhar?

### Any one of the following approach can be followed 

- Replacement of one of the Application among 59 Application

- Innovation Challenge

# **Example**

See the List [Here](https://economictimes.indiatimes.com/tech/software/india-bans-59-chinese-apps-including-tiktok-helo-wechat/articleshow/76694814.cms)
