---
title: "Education"
date: "2020-06-28"
description: "For All the Institutions Fighting Covid-19"
type: "theme"
priority: "2"
---

![](https://i1.wp.com/www.goodworklabs.com/wp-content/uploads/2016/06/education-mobile-app.jpg)

# **Overview**

As Covid-19 broke out, all the schools, colleges and other offline educational institutions suffered a drawback. Now we have learnt a lesson that we have to be prepared for such situations and the valuable time of students should not go waste. Also there has been a significant lack of quality teachers in educational institutions due to which most students are deprived of quality education and quality teachers have to work hard. Do you have an idea how technology can help students and teachers cope up with this problem?

# **Example**

Connecting teachers and students, sharing of study material, avoiding cheating during quizzes.

# **Referrals**

- https://www.trustradius.com/buyer-blog/how-technology-improves-education 