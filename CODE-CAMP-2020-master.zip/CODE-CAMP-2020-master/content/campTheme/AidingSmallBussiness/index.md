---
title: Aiding Small Businesses
date: "2020-06-30"
description: "The Theme  include setting up supply chain network, improve accounting and bookkeeping, marketing, informing business leaders about Government schemes, etc."
type: "theme"
priority: "6"
---

![](https://image.freepik.com/free-vector/cartoon-character-design-illustration-business-team-conference-exchange-ideas_1362-122.jpg)

# **Overview**

Nobody was prepared for lockdown and so almost all the businesses suffered loss. Large enterprises have sufficient funds and can easily cope up with their loss but the damage of small and medium enterprises is enormous. Many entrepreneurs are at the edge of bankruptcy. As per an article in The Hindu, almost 12.2 crore people lost their jobs in April 2020. Many companies are reducing their workforce and making salary cuts due to lack of fuel. The world is shifting its supply chain from China and India should take advantage of the situation. We have land, transport network, electricity and all it needs to set up big industries. Can you help India become Aatmnirbhar?

### Example

Would include setting up supply chain network, improve accounting and bookkeeping, marketing, informing business leaders about Government schemes, etc.

# **Referrals**

- Visit this [Link](https://yourstory.com/mystory/how-can-technology-help-to-accelerate-sme-success) for Support Article.
