---
title: Yeshwanth Vankina
description: "Currently in BYJU’s as Senior QA"
type: "judge"
priority: "4"
---

Here is Mr.Yeshwanth Vankina, He is Currently Working as Senior Quality Assurance Engineer in BYJU's (ThinknLearn), and he is here to Judge Our Event. He is very good in handling larger teams across his career also he is having Great Leadership Qualities, he has Guided larger audience to develop their career on right Path. Let us walk you through his Bio and work that is worth recognizing.

<p Align="center">
<img src="https://scontent-del1-1.xx.fbcdn.net/v/t1.0-9/87896787_2935197623186173_8413539280130932736_n.jpg?_nc_cat=111&_nc_sid=09cbfe&_nc_ohc=O2R77f4Y9qgAX-bjxQd&_nc_ht=scontent-del1-1.xx&oh=a84494b3f4423078b9f3aed5217ae068&oe=5F2E2C76"/>
</p>

---

He had Worked in Fisdom (Finwizard Technology), Redbus (IBIBO Pvt Ltd) , Quintiles IMS, Goibibo and IDS Next Business Solution Pvt Ltd 

> ### Motivation Quote
> If you think You can do it ! You will ! for Sure, In your Life, Never Compare yourself with others, everyone is Unique. Look at your fingures they are not same, is it? – Life is also same for you, you’re the boss to decide what is the best to do.

## Tech Stack

Manual Testing | Backend Testing | Android and IOS Testing | Web Application | Web services | Performance Testing | Automation with Java | Selenium | Front End Full Stack Development in Progress | Hardware and Networking | CCNA | RedhatLinux | VB 

#### Read his Technical Blogs on [Medium](https://medium.com/@yeshwanth.vankina1)

## Where to find him? 

- Add him your friend on [Facebook](https://www.facebook.com/ChallengerYeshwanth)

- Follow his work on [GitHub](https://github.com/Yesh1712/)

- Stalk him and his posts on [Instagram](https://www.instagram.com/yeshwanth.vankina/)
 
- Retweet his thoughts on [Twitter](https://twitter.com/Yeshwanth_1990)


WE ARE HAPPY TO HAVE HIM AS A JUDGE IN CODE CAMP 1.0