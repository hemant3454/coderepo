---
title: Prasoon David
description: "SDE Byjus | Ex- Unilever | Amdocs"
type: "judge"
priority: "5"
---

Prasoon is a Tech Enthusiast | Stock Market Enthusiast also automates useless stuff. he is also a hardworking person who is passionate about his work. He is a BIT Alumini, who loves play guitar and also sings. and somethimes loves to talk nerdy. Also calls himself a Part-time Cook.

<p Align="center">
<img src="../../assets/PasoonDavid.jpeg" alt="Prasoon David"/>
</p>

---

### Amdocs Hack-a-thon Winner ( Top 10 BlockChain Hackathon )

> ### Motivation Quote
> Never delete your code , comment it, You never know your Manager’sRequirement 

## Where can we find him? 

- Connect with him on [LinkedIn](https://www.linkedin.com/in/prasoon-david-5152a8165)

WE ARE HAPPY TO HAVE HIM AS A JUDGE IN CODE CAMP 1.0