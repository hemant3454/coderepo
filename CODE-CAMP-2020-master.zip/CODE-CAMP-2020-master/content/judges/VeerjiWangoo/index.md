---
title: Veer Ji Wangoo 
description: "TCS Nordics Strategic Management Professional | Ex- Microsoft MVP"
type: "judge"
priority: "6"
---

Veer Ji Wangoo is working for TCS Nordics as a Strategic Management Professional in IT Services who believes that it is equally important to have the right ways & means , methodologies & framework for a successful outcome as much as the intentions to initiate it & derive at the outcomes.

Veer Ji Wangoo has experience of 20+ years in IT Architecture, Transition , Transformation , Service Delivery & Sales Mgmt. across. He is an Ex - Microsoft MVP, certified PMP, Agile SME & an expert on Futuristic Hybrid Datacenter framework enabled with AI & Machine First approach

<p Align="center">
<img src="../../assets/Veerji.jpeg" width="300" />
</p>

---

> ### Motivation Quote
> It is equally important to have the right ways & means, methodologies & framework for a successful outcome as much as the intentions to initiate it & derive at the outcomes.

### Where to find him? 

- Connect with him on [LinkedIn](https://www.linkedin.com/in/veerjiwangoo)


WE ARE HAPPY TO HAVE HIM AS A JUDGE IN CODE CAMP 1.0