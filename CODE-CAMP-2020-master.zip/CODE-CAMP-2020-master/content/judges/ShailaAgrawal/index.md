---
title: Shaila Agrawal
description: "Data Science Engineer, Ex- Utopia Labs | Currently Freelancing."
type: "judge"
priority: "1"
---

Shaila loves exploring, composing and narrating stories through Data Science in Python. A Dance and fitness enthusiast. Also Actively participate in community services for children. 

`#WomenWhoCodes`  `#PythonHunter`  `#DataScientist`  `#Judge`  `#Author`


<p Align="left">
<img src="../../assets/Shaila.jpeg" alt="Shaila Agrawal" />
</p>

---

> ### Motivation Quote
> Hard work beats Talent when Talent doesn't work hard. - `Tim Notke` 


## What she writes other than code?

`She is a Researcher, one of her Research paper is:`

- **A Composite Approach t0 Digital Video Watermarking - ` published by Springer in` `June 2016`.**

## Where can we find her? 

- Connect with Shaila Agrawal on [LinkedIN](https://www.linkedin.com/mwlite/in/shaila-agrawal-797965b7)


### WE ARE HAPPY TO HAVE HER AS A JUDGE In CODE CAMP 1.0 
