---
type: "team"                                                        
title: DemoTeam
name: "DemoTeam"
github-link: "https://github.com/ "
description: "hello I am Bot Developer"
Team-Quote: ""
Team_Tech_Stack: ""
Application_Type: ""
No_Of_Member: ""
---

Hey ! We are Team DemoTeam. We are here to win. and we also love open source.

---

## Project's Overview

_**Theme-Name**_ : 

_**Application-Type**_ :   Web Application | Website | Mobile Application (The Application should be hosted and Bundled)

_**Idea-Description**_ :   complete idea description goes here with max 400 words.

_**Tech-Stack-Used**_ :   languages or framework used will go here.

_**GitHub-Link**_ :   Github project Repository link Goes here (make a blank repository). 

_**Hosted-Link**_ :    Hosted link goes here. (Will submit in submission Pull Request)

---

# Member Details

_**No of members**_ : 

Fill Team Details for only the valid no of members in your team and delete the leftover Template...

## Leader Details

_**Name**_ :

_**University-Name**_ : 

_**country**_ :
 
_**Technical-Skills**_ :

_**Specialization**_ :

_**GitHub-ID**_ :  

---

## Member 2 Details

_**Name**_ :

_**University-Name**_ : 

_**country**_ :
 
_**Technical-Skills**_ :

_**Specialization**_ :

_**GitHub-ID**_ :   

---

## Member 3 Details

_**Name**_ :

_**University-Name**_ : 

_**country**_ :
 
_**Technical-Skills**_ :

_**Specialization**_ :

_**GitHub-ID**_ :   

---

## Member 4 Details

_**Name**_ :

_**University-Name**_ : 

_**country**_ :
 
_**Technical-Skills**_ :

_**Specialization**_ :

_**GitHub-ID**_ :  

---

## Member 5 Details

_**Name**_ :

_**University-Name**_ : 

_**country**_ :
 
_**Technical-Skills**_ :

_**Specialization**_ :

_**GitHub-ID**_ :  

---

## Member 6 Details

_**Name**_ :

_**University-Name**_ : 

_**country**_ :
 
_**Technical-Skills**_ :

_**Specialization**_ :

_**GitHub-ID**_ :  


