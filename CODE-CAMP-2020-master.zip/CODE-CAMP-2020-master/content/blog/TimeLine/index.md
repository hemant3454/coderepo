---
title: Time Line CODE CAMP ⏳
date: "2020-06-23"
description: "The Time Line is divided into phases."
type: "blog"
priority: "2"
---

The Events timeline will be revealed on ISTE's social accounts. You can also have a look to complete timeline for the hackathon code camp below :

<p align="center">
<img src="../../assets/timeline.png"></img>
</p> 