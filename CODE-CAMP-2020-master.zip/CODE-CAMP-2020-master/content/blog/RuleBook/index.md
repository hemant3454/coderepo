---
title: Rule Book 2020 book 📕
date: "2020-06-20"
description: "Hello World"
type: "blog"
priority: "4"
---

- All the teams must abide by the code of conduct of the event. Failing to do so will lead to disqualification of team or more severe consequences .

> Read Code_of_coduct [HERE](/Code_Of_Conduct/)

- Check all the checkboxes in the checklist in the PULL-REQUEST-TEMPLATE by marking x inside the square brackets as [x].

- No plagiarism activity will be tolerated. This will lead to disqualification of the team. You are expected to come up with new and innovative ideas, any idea that has been copied from somewhere will be disqualified.

- No submission will be considered for evaluation after the deadline.

- Maximum 6 developers and minimum 1 developer are allowed in a team.

- The certificates will be given in the form of e-certificates.

- A participant can only be a part of one team. Any participant if found to be a part of multiple teams will be disqualified from the event.

- Once the Hackathon starts, you will get an option to submit your hack, you can submit as many times as you want, the last hack will be considered as the final submission.

- By participating in the Hackathon, you agree to the terms and conditions of open source.

- Owner’s decision is final and binding.
