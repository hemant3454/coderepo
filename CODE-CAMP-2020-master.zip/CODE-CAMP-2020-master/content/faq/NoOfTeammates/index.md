---
title: How many Team-Mate I can Have ?
type: "faq"
priority: "10"
tags: ["participation", "registration"]
---

![](https://i.pinimg.com/originals/b8/b8/94/b8b894c68a4784eabf5ce6c38385c9fb.gif)

# Min 1 / Max 6  😍😃

> The Number of participants in the teams can be minimum of **one** Participants or maximum of **Six** Participants. 

### **For Any Issues visit** [**Issues Here**](https://github.com/ISTESRMNCR/CODE-CAMP-2020/issues)