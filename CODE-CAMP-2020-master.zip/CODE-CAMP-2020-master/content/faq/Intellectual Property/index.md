---
title: Who will own the IP(Intellectual Property) Rights to the product that I have built?
type: "faq"
priority: "9"
tags: ["participation", "registration"]
---


The developer of the Web/Mobile Application will have all rights and own the IP of the product. However, all code needs to be in public domain (open source) so that it can be evaluated by the judges.

### NOTE : YOUR REPOSITORY SHOULD HAVE A OPEN SOURCE LICENSE

