---
title: How do I submit what I have made for the Hackathon ?
type: "faq"
priority: "7"
tags: ["participation", "registration"]
---


You have to put a link of Project's GitHub repository and the hosted link of the project in **SECOND PULL REQUEST AFTER THE PROJECT HAS BEEN MADE**. See More info [Here](https://github.com/ISTESRMNCR/CODE-CAMP-2020/blob/master/README.md)

