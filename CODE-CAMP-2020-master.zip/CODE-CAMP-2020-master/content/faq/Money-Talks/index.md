---
title: Am I investing any penny 💰 ?
type: "faq"
priority: "5"
tags: ["participation", "registration"]
---

![](https://media2.giphy.com/media/LOEI8jsNKPmzdJYvhJ/giphy.gif)

The Hackathon is free of cost. Only time, attention, skills required. Winners will be provided with some perks. 😍


# WIN WIN SITUATION 👑