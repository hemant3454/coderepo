---
title: Who can participate in this challenge ?
type: "faq"
priority: "3"
tags: ["participation", "registration"]
---

![Everyone](https://media3.giphy.com/media/7cTTE2Z1OmrFm/200.gif)

Yes! The participation is open for everyone. It is also _free_.

Person who codesor love to code can participate in this challenge... By issuing the Pull Request here 👉 [PULL REQUEST to Repository](https://github.com/ISTESRMNCR/CODE-CAMP-2020)

This Hackathon is a virtual Open Source hackathon with all harassment free CODE_OF_CONDUCT

Any Student | graduates | Open-Source teams who loves to code 👨‍💻 are welcome. 🙏

- Open-source Teams
- High School Graduates
- College Graduates
- Anyone who loves to code 👨‍💻.

Visit our _CODE OF CONDUCT_ [Here](https://gitub.com/ISTESRMNCR/CODE-CAMP-2020/CODE_OF_CONDUCT) 👈
