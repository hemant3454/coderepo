---
title: What are Hackathons ?
type: "faq"
priority: "2"
tags: ["participation", "registration"]
---

![](https://miro.medium.com/max/2880/1*PiJiIxMhkMfKnIOJlwIEHw.jpeg)

Hackathons brings people from different fields— Pharmacists, Entrepreneurs, Software developers, Engineers together in one place.Folks collaborate among themselves and work in teams to solve a real-life problem. The overall objective of the Hackathons is to inspire innovation and create out of the box solutions. Attending a Hackathons is a great way to meet and work with new people, come up with exciting, innovative ideas and learn interesting technologies.

## **(Hackathon)**   **?**🤩 **:**    😭  

![hackathons](https://pbs.twimg.com/media/CAnDwJmWoAA7Mdm.jpg)

Hackathons are really known for their Prizes and Sponsors and this time ISTE's Student Chapter SRM NCR, brings you the same.

So what are you waiting for... [**Register Now**](https://github.com/ISTESRMNCR/CODE-CAMP-2020#readme) 👈