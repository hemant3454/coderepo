// custom typefaces
import "typeface-montserrat"
import "typeface-merriweather"
import "./src/styles/global.css"

import "prismjs/themes/prism.css"
